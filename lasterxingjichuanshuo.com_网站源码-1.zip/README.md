# LASTER《龙舌兰：星际传说》官方世界档案

目标域名：lasterxingjichuanshuo.com

## 已包含
- 第一季小说全文（以本项目生成时最新提供的 TXT 为准）
- 第二季小说全文（采用当前提供文件中篇章最完整的版本；另附较新修订稿存档）
- 五位主要角色图片与 Wiki 摘要
- LASTER 作者头像
- 世界观“启灵”与五位降临者说明
- 全站搜索 + 内置档案讲解
- 卷/回目录、上一回/下一回、阅读进度、字体大小
- PWA manifest
- CNAME：lasterxingjichuanshuo.com

## 部署到 .com
1. 购买/确认域名 lasterxingjichuanshuo.com。
2. 将整个文件夹部署到支持静态网站的托管服务。
3. 在托管平台添加自定义域名 `lasterxingjichuanshuo.com`。
4. 按平台提示配置 DNS。
5. 本项目已附 CNAME，可用于支持 CNAME 的静态托管方案。

## 注意
小说正文来自用户提供的 TXT 文件；本项目不会修改正文内容，只在浏览器端按“卷/回”标题解析。图片是提供的原始图片资产，网页没有在图片上额外叠加文字。
