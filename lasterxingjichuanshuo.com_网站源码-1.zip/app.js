
const $=s=>document.querySelector(s); const $$=s=>[...document.querySelectorAll(s)];
let chapters=[], current=0, explain={};
const charData=[
{id:'qiufeng',name:'秋风',height:'182 cm',role:'万能助手 / 执行者',power:'终焉降临者',keywords:'普通人 · 适应 · 责任 · 陪伴',img:'assets/qiufeng.png',desc:'什么都会一点，却没有一样达到顶尖。摄影、编程、剪辑、日语、驾驶等技能，在团队旅途中逐渐成为真正的价值。第一季核心主题与“普通人在极端环境中的选择”相连。'},
{id:'shiyi',name:'时忆',height:'162 cm',role:'总导演 / 编剧',power:'五位降临者之谜的核心成员',keywords:'成熟 · 领导 · 秘密 · 宿命',img:'assets/shiyi.png',desc:'外表像十二三岁的小女孩，却拥有远超外表的成熟与领导力。她负责剧本、分镜、演员、拍摄、谈判和团队管理，是工作室真正的核心。'},
{id:'xuanqing',name:'玄青',height:'158 cm',role:'主演 / 服装道具',power:'自然降临者',keywords:'傲娇 · 敏感 · 认真 · 自然',img:'assets/xuanqing.png',desc:'银蓝色长发、异色蓝眸。嘴硬心软、容易害羞，但进入工作状态后要求极高，一个镜头可以反复拍摄几十次。与自然篇的力量伏笔相连。'},
{id:'naike',name:'奈可',height:'157 cm',role:'摄影 / 场务',power:'甜蜜降临者',keywords:'活泼 · 乐观 · 细心 · 温暖',img:'assets/naike.png',desc:'表面大大咧咧，实际上非常细心。小熊背包里常备数据线、备用电池、纸巾、雨伞等，擅长在拍摄现场照顾整个团队。'},
{id:'mazi',name:'艾尔多莉·麻子',height:'159 cm',role:'副导演 / 心理指导',power:'幻影降临者',keywords:'安静 · 观察 · 逻辑 · 理解',img:'assets/mazi.png',desc:'话很少，却拥有敏锐的观察力。她能发现剧本逻辑漏洞、演员情绪变化、道具位置与细节问题，并把观察转化为解决方案。'}];
function parseNovel(text,season){const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/);let arr=[];let start=-1,title='';let volume='';for(let i=0;i<lines.length;i++){let m=lines[i].trim().match(/^(第[一二三四五六七八九十百0-9]+卷---[^\n]+?)\s+(第[一二三四五六七八九十百0-9]+回.*)$/);if(m){if(start>=0)arr.push({title,volume,body:lines.slice(start,i).join('\n').trim(),season});volume=m[1];title=m[2];start=i+1}}if(start>=0)arr.push({title,volume,body:lines.slice(start).join('\n').trim(),season});return arr}
async function init(){
 const [a,b,e]=await Promise.all([fetch('data/season1.txt').then(r=>r.text()),fetch('data/season2.txt').then(r=>r.text()),fetch('data/explain.json').then(r=>r.json())]); explain=e; chapters=[...parseNovel(a,'第一季'),...parseNovel(b,'第二季')];
 buildChars();buildVolumes();buildToc();renderChapter(0);$('#chapterCount').textContent=chapters.length+' 回';
}
function buildChars(){$('#charGrid').innerHTML=charData.map((c,i)=>`<article class="card glass" data-char="${i}"><img src="${c.img}" alt="${c.name}"><div class="cardbody"><h3>${c.name}</h3><div class="muted">${c.height} · ${c.role}</div><div class="power">${c.power}</div></div></article>`).join('');$$('[data-char]').forEach(x=>x.onclick=()=>showChar(+x.dataset.char))}
function showChar(i){let c=charData[i];$('#modalContent').innerHTML=`<div class="profile"><img src="${c.img}"><div><span class="tag">角色档案</span><h2>${c.name}</h2><p class="muted">${c.height} · ${c.role}</p><p>${c.desc}</p><p>${c.keywords.split(' · ').map(x=>`<span class="tag">${x}</span>`).join('')}</p><div class="explain glass"><b>权能 / 关联</b><p>${c.power}</p></div></div></div>`;$('#modal').classList.add('open')}
function buildVolumes(){let seen=[];chapters.forEach(c=>{if(!seen.some(x=>x.v===c.volume))seen.push({v:c.volume,n:chapters.filter(q=>q.volume===c.volume).length,season:c.season})});$('#volumeGrid').innerHTML=seen.map((x,i)=>`<button class="vol glass" onclick="jumpVolume(${chapters.findIndex(c=>c.volume===x.v)})"><span class="num">${i+1}</span><div><b>${x.v}</b><br><span>${x.season} · ${x.n} 回</span></div></button>`).join('')}
function buildToc(){let last='';$('#toc').innerHTML=chapters.map((c,i)=>{let head=c.volume!==last?`<div class="muted" style="padding:12px 10px 5px;font-weight:800">${c.volume}</div>`:'';last=c.volume;return head+`<button onclick="renderChapter(${i})" id="toc-${i}">${c.title}</button>`}).join('')}
function renderChapter(i){current=Math.max(0,Math.min(chapters.length-1,i));let c=chapters[current];$('#chapterTitle').textContent=c.title;$('#chapterMeta').textContent=`${c.season} · ${c.volume}`;$('#novel').textContent=c.body;$$('.toc button').forEach(x=>x.classList.remove('active'));$('#toc-'+current)?.classList.add('active');$('#reader').scrollIntoView({behavior:'smooth',block:'start'});localStorage.setItem('lasterChapter',current);updateButtons()}
function updateButtons(){let p=$('#prev'),n=$('#next');p.disabled=current===0;n.disabled=current===chapters.length-1;p.onclick=()=>renderChapter(current-1);n.onclick=()=>renderChapter(current+1)}
window.jumpVolume=i=>renderChapter(i);
function searchAll(q){q=q.trim().toLowerCase();if(!q){$('#searchResults').innerHTML='';return}let out=[];chapters.forEach((c,i)=>{let idx=c.body.toLowerCase().indexOf(q);if(idx>=0){let sn=c.body.slice(Math.max(0,idx-80),idx+q.length+130).replace(/\n+/g,' ');out.push(`<div class="result" onclick="renderChapter(${i})"><b>${c.title}</b><small>${c.volume} · ${sn}</small></div>`);}});let defs=Object.entries(explain).filter(([k,v])=>k.toLowerCase().includes(q)||v.toLowerCase().includes(q)).map(([k,v])=>`<div class="result" onclick="showExplain('${k.replaceAll("'","\\'")}')"><b>档案解释：${k}</b><small>${v}</small></div>`);$('#searchResults').innerHTML=(defs.concat(out)).slice(0,30).join('')||'<div class="muted">没有找到对应内容。</div>'}
window.showExplain=k=>{$('#modalContent').innerHTML=`<div class="explain glass"><span class="tag">世界档案 · 内置讲解</span><h2>${k}</h2><p>${explain[k]||'当前设定资料中没有更具体的解释。'}</p></div>`;$('#modal').classList.add('open')}
$('#searchBtn').onclick=()=>searchAll($('#globalSearch').value);$('#globalSearch').oninput=e=>searchAll(e.target.value);
$('#closeModal').onclick=()=>$('#modal').classList.remove('open');$('#modal').onclick=e=>{if(e.target.id==='modal')$('#modal').classList.remove('open')};
$('#fontUp').onclick=()=>{let x=parseFloat(getComputedStyle($('#novel')).fontSize);$('#novel').style.fontSize=Math.min(28,x+1)+'px'};$('#fontDown').onclick=()=>{let x=parseFloat(getComputedStyle($('#novel')).fontSize);$('#novel').style.fontSize=Math.max(14,x-1)+'px'};
window.addEventListener('scroll',()=>{let h=document.documentElement.scrollHeight-innerHeight;$('#progress').style.width=(h?scrollY/h*100:0)+'%'});
const saved=+localStorage.getItem('lasterChapter'); if(Number.isFinite(saved)&&saved>=0) setTimeout(()=>renderChapter(Math.min(saved,chapters.length-1)),500);
init();

if('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(()=>{});
